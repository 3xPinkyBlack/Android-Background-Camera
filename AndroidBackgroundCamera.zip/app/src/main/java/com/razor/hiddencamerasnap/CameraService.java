package com.razor.hiddencamerasnap;

import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PixelFormat;
import android.hardware.Camera;
import android.media.MediaScannerConnection;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;
import android.view.WindowManager;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

public class CameraService extends Service {
    public static Camera camera = null;

    @Override
    public IBinder onBind(Intent intent) {
        return  null;
    }

    public int onStartCommand(Intent intent, int flags, int startId) {
        final SurfaceView preview = new SurfaceView(this);
        SurfaceHolder holder = preview.getHolder();
        preview.setZOrderOnTop(true);
        holder.setFormat(PixelFormat.TRANSLUCENT);
        holder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
        holder.addCallback(new Callback() {
            public void surfaceCreated(SurfaceHolder holder) {
                try {
                    camera = Camera.open();
                    int cHeight = 0;
                    int cWidth = 0;
                    Camera.Parameters params = camera.getParameters();
                    List<Camera.Size> sizes = params.getSupportedPictureSizes();
                    for(Camera.Size size : sizes) {
                        cHeight = size.height;
                        cWidth = size.width;
                    }
                    params.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE);
                    params.setRotation(90);
                    params.setPictureSize(cWidth, cHeight);
                    camera.setParameters(params);
                    try {
                        camera.setPreviewDisplay(holder);
                    } catch(IOException e) {}
                    camera.startPreview();
                    final Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            camera.takePicture(null, null, new Camera.PictureCallback() {
                                public void onPictureTaken(byte[] data, Camera camera) {
                                    Bitmap mybitmap = BitmapFactory.decodeByteArray(data,0,data.length);
                                    ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                                    mybitmap.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
                                    String dir = Environment.getExternalStorageDirectory()+"";
                                    try {
                                        File f = new File(dir, "myHiddenImage.jpeg");
                                        f.createNewFile();
                                        FileOutputStream fo = new FileOutputStream(f);
                                        fo.write(bytes.toByteArray());
                                        MediaScannerConnection.scanFile(CameraService.this, new String[] {f.getPath()}, new String[]{"image/jpeg"}, null);
                                        fo.close();
                                        showMessage("Picture Successfully Taken");
                                    } catch (Exception e) {}
                                    camera.release();
                                }
                            });
                        }
                    }, 2000);
                } catch (Exception e) {
                    if(camera != null) {camera.release();}
                }
            }
            public void surfaceDestroyed(SurfaceHolder hodlder) {};
            public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {}
        });
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                1,1,
                WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY,
                0,
                PixelFormat.TRANSPARENT
        );

        wm.addView(preview, params);

        return START_STICKY;
    }

    public void showMessage(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }
}
